#!/usr/bin/env python3
"""
wcl_parser.py — WarcraftLogs Classic Fresh realm scraper

Scrapes ALL public parse data for every player on the Dreamscythe realm
without requiring a manual character list.  Stores best parse per boss and
Best Perf. Average in a local SQLite database.

Strategy
--------
Phase 1 – Discover characters:
  Paginate through each encounter's character rankings filtered by serverSlug
  and serverRegion.  Every character who has ever logged a parse shows up here.

Phase 2 – Fetch zone summaries:
  For each unique character found, call character.zoneRankings(zoneID) to get
  WCL's official Best Perf. Average and per-boss best parses.  Skips characters
  whose data was fetched within REFRESH_HOURS hours (set to 0 to always refresh).

Usage
-----
    python wcl_parser.py --discover          # list zones/encounters + their IDs
    python wcl_parser.py --sync              # scrape entire Dreamscythe realm
    python wcl_parser.py --char Dotabuff     # fetch a single character only

Environment variables (required):
    WCL_CLIENT_ID      — WarcraftLogs OAuth client ID
    WCL_CLIENT_SECRET  — WarcraftLogs OAuth client secret

Get API credentials: https://www.warcraftlogs.com/api/clients/
"""

import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone

import requests

# ─── Configuration ────────────────────────────────────────────────────────────

CLIENT_ID     = os.environ.get("WCL_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("WCL_CLIENT_SECRET", "")

SERVER_SLUG   = "dreamscythe"
SERVER_REGION = "US"

# Classic Fresh TBC zone IDs (run --discover to verify / find new ones):
#   1047 = Karazhan
#   1048 = Gruul / Magtheridon  (High King Maulgar, Gruul, Magtheridon = 3 bosses)
ZONE_IDS: list[int] = [1048, 1047]

# Characters updated within this many hours are skipped during --sync.
# Set to 0 to always re-fetch everyone.
REFRESH_HOURS: int = 24

# How many characters to fetch in a single batched GraphQL call.
# Each batch = 1 API call regardless of batch size.
# Reduce if WCL returns complexity errors; increase if you want faster syncs.
BATCH_SIZE: int = 10

# Seconds to sleep between API calls to stay well under the rate limit.
# WCL allows ~3600 points/hour; each query costs ~1 point.  0.25 s ≈ safe.
REQUEST_DELAY: float = 0.25

DB_PATH   = "wcl_parses.db"
TOKEN_URL = "https://www.warcraftlogs.com/oauth/token"
API_URL   = "https://www.warcraftlogs.com/api/v2/client"

# ─── Auth ─────────────────────────────────────────────────────────────────────

def get_token() -> str:
    resp = requests.post(
        TOKEN_URL,
        data={"grant_type": "client_credentials"},
        auth=(CLIENT_ID, CLIENT_SECRET),
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


# ─── GraphQL helper ───────────────────────────────────────────────────────────

def gql(token: str, query: str, variables: dict | None = None) -> dict:
    """Run a GraphQL query and return the data payload.

    Logs GraphQL field-level errors but does not raise — batched queries can
    return partial data (e.g. one character not found) alongside valid results.
    Only raises on HTTP errors or when there is no data at all.
    """
    headers = {"Authorization": f"Bearer {token}"}
    payload: dict = {"query": query}
    if variables:
        payload["variables"] = variables
    resp = requests.post(API_URL, json=payload, headers=headers, timeout=20)
    resp.raise_for_status()
    body = resp.json()
    if errors := body.get("errors"):
        # Print but don't raise — partial data may still be usable.
        for e in errors:
            print(f"  [GQL warn] {e.get('message', e)}")
    if body.get("data") is None:
        raise RuntimeError("GraphQL returned no data.")
    time.sleep(REQUEST_DELAY)
    return body["data"]


# ─── Queries ──────────────────────────────────────────────────────────────────

_DISCOVER_QUERY = """
{
  worldData {
    zones {
      id
      name
      difficulties { id  name  sizes }
      encounters   { id  name }
    }
  }
}
"""

# Phase 1: paginate encounter rankings filtered to one server.
# characterRankings returns a JSON scalar with { data: [...], total, per_page,
# current_page, last_page, has_more_pages }.  Each entry includes name, class,
# spec, rankPercent, amount, etc.
_ENCOUNTER_RANKINGS_QUERY = """
query EncounterRankings(
  $encounterID: Int!
  $serverSlug: String!
  $serverRegion: String!
  $page: Int!
) {
  worldData {
    encounter(id: $encounterID) {
      name
      characterRankings(
        serverSlug: $serverSlug
        serverRegion: $serverRegion
        page: $page
      )
    }
  }
}
"""

# Fetch encounter IDs for a zone so we know what to paginate.
_ZONE_ENCOUNTERS_QUERY = """
query ZoneEncounters($zoneID: Int!) {
  worldData {
    zone(id: $zoneID) {
      name
      encounters { id  name }
    }
  }
}
"""

# ─── Database ─────────────────────────────────────────────────────────────────

_SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS characters (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    server_slug TEXT    NOT NULL,
    region      TEXT    NOT NULL,
    class_id    INTEGER,
    updated_at  TEXT    NOT NULL,
    UNIQUE (name, server_slug, region)
);

-- Best Perf. Average per zone (as shown on the character summary page).
CREATE TABLE IF NOT EXISTS zone_summaries (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    character_id    INTEGER NOT NULL REFERENCES characters(id),
    zone_id         INTEGER NOT NULL,
    zone_name       TEXT,
    best_perf_avg   REAL,
    median_perf_avg REAL,
    updated_at      TEXT    NOT NULL,
    UNIQUE (character_id, zone_id)
);

-- Best parse per boss per character.
CREATE TABLE IF NOT EXISTS boss_parses (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    character_id    INTEGER NOT NULL REFERENCES characters(id),
    zone_id         INTEGER NOT NULL,
    encounter_id    INTEGER NOT NULL,
    encounter_name  TEXT,
    rank_percent    REAL,
    median_percent  REAL,
    best_amount     REAL,
    best_spec       TEXT,
    metric          TEXT,
    updated_at      TEXT    NOT NULL,
    UNIQUE (character_id, zone_id, encounter_id)
);
"""


def open_db(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.executescript(_SCHEMA)
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def upsert_character(conn, name, server_slug, region, class_id) -> int:
    conn.execute(
        """
        INSERT INTO characters (name, server_slug, region, class_id, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(name, server_slug, region) DO UPDATE SET
            class_id   = excluded.class_id,
            updated_at = excluded.updated_at
        """,
        (name, server_slug, region, class_id, _now()),
    )
    conn.commit()
    return conn.execute(
        "SELECT id FROM characters WHERE name=? AND server_slug=? AND region=?",
        (name, server_slug, region),
    ).fetchone()[0]


def upsert_zone_summary(conn, char_id, zone_id, zone_name, best_avg, median_avg):
    conn.execute(
        """
        INSERT INTO zone_summaries
            (character_id, zone_id, zone_name, best_perf_avg, median_perf_avg, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(character_id, zone_id) DO UPDATE SET
            zone_name       = excluded.zone_name,
            best_perf_avg   = excluded.best_perf_avg,
            median_perf_avg = excluded.median_perf_avg,
            updated_at      = excluded.updated_at
        """,
        (char_id, zone_id, zone_name, best_avg, median_avg, _now()),
    )
    conn.commit()


def upsert_boss_parse(conn, char_id, zone_id, enc_id, enc_name,
                      rank_pct, median_pct, amount, spec, metric):
    conn.execute(
        """
        INSERT INTO boss_parses
            (character_id, zone_id, encounter_id, encounter_name, rank_percent,
             median_percent, best_amount, best_spec, metric, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(character_id, zone_id, encounter_id) DO UPDATE SET
            encounter_name = excluded.encounter_name,
            rank_percent   = excluded.rank_percent,
            median_percent = excluded.median_percent,
            best_amount    = excluded.best_amount,
            best_spec      = excluded.best_spec,
            metric         = excluded.metric,
            updated_at     = excluded.updated_at
        """,
        (char_id, zone_id, enc_id, enc_name, rank_pct, median_pct, amount, spec, metric, _now()),
    )
    conn.commit()


def recently_updated(conn, name, server_slug, region, hours: int) -> bool:
    """Return True if this character was fetched within `hours` hours."""
    if hours <= 0:
        return False
    row = conn.execute(
        "SELECT updated_at FROM characters WHERE name=? AND server_slug=? AND region=?",
        (name, server_slug, region),
    ).fetchone()
    if not row:
        return False
    updated = datetime.fromisoformat(row[0])
    return datetime.now(timezone.utc) - updated < timedelta(hours=hours)


# ─── Phase 1: discover all characters via encounter rankings ──────────────────

def get_zone_encounter_ids(token: str, zone_id: int) -> list[tuple[int, str]]:
    """Return [(encounter_id, encounter_name), ...] for a zone."""
    data = gql(token, _ZONE_ENCOUNTERS_QUERY, {"zoneID": zone_id})
    zone = data["worldData"]["zone"]
    if zone is None:
        print(f"  Zone {zone_id} not found.")
        return []
    return [(e["id"], e["name"]) for e in zone.get("encounters") or []]


def scrape_encounter_characters(
    token: str,
    encounter_id: int,
    server_slug: str,
    server_region: str,
) -> set[str]:
    """
    Paginate through all character rankings for one encounter on one server.
    Returns a set of character names.
    """
    names: set[str] = set()
    page = 1

    while True:
        data = gql(token, _ENCOUNTER_RANKINGS_QUERY, {
            "encounterID":  encounter_id,
            "serverSlug":   server_slug,
            "serverRegion": server_region,
            "page":         page,
        })

        raw = data["worldData"]["encounter"]["characterRankings"]
        if not raw:
            break

        rankings: dict = json.loads(raw) if isinstance(raw, str) else raw
        entries = rankings.get("data") or rankings.get("rankings") or []

        for entry in entries:
            # The name field may sit at the top level or inside a "character" sub-object.
            name = entry.get("name") or (entry.get("character") or {}).get("name")
            if name:
                names.add(name)

        has_more = rankings.get("has_more_pages", False)
        last_page = rankings.get("last_page", page)

        print(
            f"    Page {page}/{last_page}  —  {len(entries)} entries"
            f"  (total found so far: {len(names)})",
            end="\r",
        )

        if not has_more or page >= last_page:
            break
        page += 1

    print()  # newline after \r progress
    return names


def discover_all_realm_characters(
    token: str,
    zone_ids: list[int],
    server_slug: str,
    server_region: str,
) -> set[str]:
    """
    Phase 1: walk every encounter in every zone and collect all character names
    who have a logged parse on the given server.
    """
    all_names: set[str] = set()

    for zone_id in zone_ids:
        print(f"\n── Zone {zone_id}: fetching encounter list...")
        encounters = get_zone_encounter_ids(token, zone_id)
        if not encounters:
            continue

        for enc_id, enc_name in encounters:
            print(f"  Encounter {enc_id} – {enc_name}")
            names = scrape_encounter_characters(
                token, enc_id, server_slug, server_region
            )
            print(f"    Found {len(names)} unique characters.")
            all_names |= names

    return all_names


# ─── Phase 2: batch fetch zone rankings ──────────────────────────────────────

def _chunks(lst: list, n: int):
    """Yield successive n-sized slices of lst."""
    for i in range(0, len(lst), n):
        yield lst[i : i + n]


def _build_batch_query(names: list[str], server_slug: str, region: str, zone_ids: list[int]) -> str:
    """
    Build a single GraphQL query that fetches N characters × all zones at once.

    Uses field aliases so every character and every zone lands in one HTTP call:
      c0: characterData { character(name: "A", ...) { z1048: zoneRankings(zoneID: 1048) ... } }
      c1: characterData { character(name: "B", ...) { z1048: zoneRankings(zoneID: 1048) ... } }

    WoW character names are restricted to [A-Za-z] so string interpolation is safe.
    """
    zone_fields = "\n      ".join(f"z{z}: zoneRankings(zoneID: {z})" for z in zone_ids)
    blocks = []
    for i, name in enumerate(names):
        blocks.append(
            f'  c{i}: characterData {{\n'
            f'    character(name: "{name}", serverSlug: "{server_slug}", serverRegion: "{region}") {{\n'
            f'      name\n'
            f'      classID\n'
            f'      {zone_fields}\n'
            f'    }}\n'
            f'  }}'
        )
    return "{\n" + "\n".join(blocks) + "\n}"


def _store_character_rankings(
    conn: sqlite3.Connection,
    name: str,
    server_slug: str,
    region: str,
    char: dict,
    zone_ids: list[int],
) -> None:
    """Persist one character's data from a batch response into the DB."""
    char_id = upsert_character(conn, name, server_slug, region, char.get("classID"))

    for zone_id in zone_ids:
        raw = char.get(f"z{zone_id}")
        if not raw:
            continue

        rankings: dict = json.loads(raw) if isinstance(raw, str) else raw
        best_avg   = rankings.get("bestPerformanceAverage")
        median_avg = rankings.get("medianPerformanceAverage")
        zone_obj   = rankings.get("zone")
        zone_name  = zone_obj.get("name") if isinstance(zone_obj, dict) else None

        upsert_zone_summary(conn, char_id, zone_id, zone_name, best_avg, median_avg)

        for boss in rankings.get("rankings") or []:
            enc      = boss.get("encounter") or {}
            enc_id   = enc.get("id")
            enc_name = enc.get("name", "Unknown")
            if enc_id is None:
                continue
            upsert_boss_parse(
                conn, char_id, zone_id, enc_id, enc_name,
                boss.get("rankPercent"),
                boss.get("medianPercent"),
                boss.get("bestAmount"),
                boss.get("bestSpec"),
                boss.get("metric"),
            )


def fetch_batch(
    token: str,
    conn: sqlite3.Connection,
    names: list[str],
    server_slug: str,
    region: str,
    zone_ids: list[int],
) -> None:
    """
    Fetch and store zone rankings for a batch of characters in a single API call.
    Characters not found or with no data are silently skipped.
    """
    query = _build_batch_query(names, server_slug, region, zone_ids)
    data  = gql(token, query)

    for i, name in enumerate(names):
        char_block = data.get(f"c{i}") or {}
        char       = char_block.get("character")
        if not char:
            continue
        _store_character_rankings(conn, name, server_slug, region, char, zone_ids)


# ─── Modes ────────────────────────────────────────────────────────────────────

def cmd_discover(token: str) -> None:
    print("Fetching all zones/encounters...\n")
    data = gql(token, _DISCOVER_QUERY)
    for zone in data["worldData"]["zones"]:
        print(f"Zone {zone['id']:>6}:  {zone['name']}")
        for diff in zone.get("difficulties") or []:
            sizes = ", ".join(str(s) for s in diff.get("sizes") or [])
            print(f"           Difficulty {diff['id']}: {diff['name']}"
                  + (f"  (sizes: {sizes})" if sizes else ""))
        for enc in zone.get("encounters") or []:
            print(f"           Encounter  {enc['id']}: {enc['name']}")
        print()


def cmd_sync(token: str, conn: sqlite3.Connection) -> None:
    """Full realm scrape: discover every character then fetch their zone data."""

    # ── Phase 1 ───────────────────────────────────────────────────────────────
    print(f"Phase 1: Discovering all characters on {SERVER_SLUG}-{SERVER_REGION}...")
    all_names = discover_all_realm_characters(token, ZONE_IDS, SERVER_SLUG, SERVER_REGION)
    print(f"\nTotal unique characters discovered: {len(all_names)}\n")

    # ── Phase 2 ───────────────────────────────────────────────────────────────
    print("Phase 2: Fetching zone rankings per character...")
    pending = sorted(
        n for n in all_names
        if not recently_updated(conn, n, SERVER_SLUG, SERVER_REGION, REFRESH_HOURS)
    )
    skipped = len(all_names) - len(pending)
    if skipped:
        print(f"  Skipping {skipped} characters refreshed within the last {REFRESH_HOURS}h.")

    total_batches = max(1, (len(pending) + BATCH_SIZE - 1) // BATCH_SIZE)
    for batch_num, batch in enumerate(_chunks(pending, BATCH_SIZE), 1):
        print(f"  Batch {batch_num}/{total_batches}: {', '.join(batch)}")
        try:
            fetch_batch(token, conn, batch, SERVER_SLUG, SERVER_REGION, ZONE_IDS)
        except Exception as exc:
            print(f"    ERROR: {exc}")


def cmd_single_char(token: str, conn: sqlite3.Connection, name: str) -> None:
    """Fetch one character by name."""
    print(f"Fetching {name} on {SERVER_SLUG}-{SERVER_REGION}...\n")
    fetch_batch(token, conn, [name], SERVER_SLUG, SERVER_REGION, ZONE_IDS)

    # Print a summary of what was stored.
    char_row = conn.execute(
        "SELECT id, class_id FROM characters WHERE name=? AND server_slug=? AND region=?",
        (name, SERVER_SLUG, SERVER_REGION),
    ).fetchone()
    if not char_row:
        print("Character not found or has no public logs.")
        return

    char_id, class_id = char_row
    print(f"  classID: {class_id}")

    for zone_id in ZONE_IDS:
        summary = conn.execute(
            "SELECT zone_name, best_perf_avg, median_perf_avg FROM zone_summaries"
            " WHERE character_id=? AND zone_id=?",
            (char_id, zone_id),
        ).fetchone()
        if not summary:
            continue
        zone_name, best_avg, median_avg = summary
        print(f"\n  {zone_name or f'Zone {zone_id}'}:")
        print(f"    Best Perf. Avg:   {best_avg}")
        print(f"    Median Perf. Avg: {median_avg}")

        parses = conn.execute(
            "SELECT encounter_name, rank_percent, best_amount, metric, best_spec"
            " FROM boss_parses WHERE character_id=? AND zone_id=?"
            " ORDER BY encounter_name",
            (char_id, zone_id),
        ).fetchall()
        for enc_name, rp, amount, metric, spec in parses:
            rp_str = f"{rp:6.2f}%" if rp is not None else "   N/A "
            print(f"    [{rp_str}]  {enc_name}  —  {amount} {metric} ({spec})")


# ─── Entry point ──────────────────────────────────────────────────────────────

def main() -> None:
    if not CLIENT_ID or not CLIENT_SECRET:
        print(
            "ERROR: WCL_CLIENT_ID and WCL_CLIENT_SECRET must be set.\n"
            "Get credentials at: https://www.warcraftlogs.com/api/clients/"
        )
        sys.exit(1)

    print("Authenticating...")
    token = get_token()
    print("OK.\n")

    args = sys.argv[1:]

    if "--discover" in args:
        cmd_discover(token)
        return

    conn = open_db(DB_PATH)
    try:
        if "--sync" in args:
            cmd_sync(token, conn)

        elif "--char" in args:
            idx = args.index("--char")
            if idx + 1 >= len(args):
                print("ERROR: --char requires a character name argument.")
                sys.exit(1)
            cmd_single_char(token, conn, args[idx + 1])

        else:
            # Default: single character (Dotabuff) for quick testing.
            cmd_single_char(token, conn, "Dotabuff")

    finally:
        conn.close()

    print(f"\nDone. Database: {DB_PATH}")


if __name__ == "__main__":
    main()
